package spotify.view;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import spotify.entidades.Album;
import spotify.entidades.Artista;

public class PrincipalSpotify {

	public static void main(String[] args) {

		try {

			Map<String, Artista> map = new HashMap<>();

			JSONArray json = new JSONArray();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(new FileInputStream(new File("lib.json")), "Cp1252"));
			JSONParser parser = new JSONParser();

			json = (JSONArray) parser.parse(reader);

			Iterator<?> i = json.iterator();

			while (i.hasNext()) {
				JSONObject obj = (JSONObject) i.next();
				String artist = (String) obj.get("artist");
				String album = (String) obj.get("album");
				String track = (String) obj.get("track");

				Artista art = map.get(artist);
				if (art == null) {
					art = new Artista();
					art.setNome(artist);
					Album bum = new Album();
					bum.getMusicas().add(track);
					art.getAlbums().put(album, bum);

				} else {
					Album bum = art.getAlbums().get(album);
					if (bum == null) {
						bum = new Album();
						bum.getMusicas().add(track);
					} else {
						bum.getMusicas().add(track);
					}
				}

				map.put(artist, art);
			}

			/*
			 * map.remove("50 Cent"); map.remove("A Flock Of Seagulls"); map.remove("ABBA");
			 * map.remove("ANAVIT�RIA"); map.remove("Acid Ghost"); map.remove("Akon");
			 * map.remove("Alan Freeman"); map.remove("Alexander Glazunov");
			 * map.remove("Alok"); map.remove("Alphaville"); map.remove("Amorphis");
			 * map.remove("Apocalyptica"); map.remove("Aram Khachaturian");
			 * map.remove("Arcade Fire"); map.remove("Arthur Alexander");
			 * map.remove("Audioslave"); map.remove("Avatar");
			 * map.remove("Avenged Sevenfold"); map.remove("Ben Moody");
			 * map.remove("Beverly"); map.remove("Beyonc�"); map.remove("Bob Dylan");
			 * map.remove("Bonnie Tyler"); map.remove("Brian Epstein");
			 * map.remove("Brian Ferry"); map.remove("Brian Matthew");
			 * map.remove("Bullet For My Valentine"); map.remove("Capital Inicial");
			 * map.remove("Carly Simon"); map.remove("Celtic Music Voyages");
			 * map.remove("Charon"); map.remove("Cigarettes After Sex");
			 * map.remove("Cold War Kids"); map.remove("Deep Purple");
			 * map.remove("Depeche Mode"); map.remove("Dream Theater");
			 * map.remove("Dua Lipa"); map.remove("Duran Duran"); map.remove("Ed Sheeran");
			 * map.remove("Edguy"); map.remove("Elis"); map.remove("Elliott Smith");
			 * map.remove("Elton John"); map.remove("Engenheiros Do Hawaii");
			 * map.remove("Lana Del Rey"); map.remove("Legi�o Urbana");
			 * map.remove("Molotov Cocktail Piano"); map.remove("Morrissey");
			 * map.remove("Opeth"); map.remove("Parov Stelar");
			 * map.remove("Piano Dreamers"); map.remove("The Beatles");
			 * map.remove("The Smiths");
			 */

			List<String> list = new ArrayList<>(map.keySet());
			Collections.sort(list);

			for (String artista : list) {
				Artista a = map.get(artista);
				Map<String, Album> bm = a.getAlbums();
				List<String> listAlbum = new ArrayList<>(bm.keySet());
				Collections.sort(listAlbum);

				for (String in : listAlbum) {
					Album b = bm.get(in);
					List<String> musics = b.getMusicas();
					Collections.sort(musics);

					for (String m : musics) {
						// System.out.println(artista + ";" + in + ";" + m + ";" + artista + " - " + m);
					}
				}
			}

			// parte dos albuns

			JSONArray jsonAlbum = new JSONArray();
			BufferedReader readerA = new BufferedReader(
					new InputStreamReader(new FileInputStream(new File("albums.json")), "Cp1252"));

			jsonAlbum = (JSONArray) parser.parse(readerA);

			Iterator<?> ia = jsonAlbum.iterator();

			while (ia.hasNext()) {
				JSONObject obj = (JSONObject) ia.next();
				String artist = (String) obj.get("artist");
				String album = (String) obj.get("album");
				String inexistente = "Album inexistente: " + album;

				Artista a = map.get(artist);

				if (a != null) {
					Map<String, Album> aa = a.getAlbums();

					if (aa == null) {
						System.out.println(inexistente);
					}
				} else {
					System.out.println(inexistente);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
