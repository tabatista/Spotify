package spotify.entidades;

import java.util.HashMap;
import java.util.Map;

public class Artista {

	private String nome;
	private Map<String, Album> albums;

	public Artista() {
		super();
		this.albums = new HashMap<>();
	}

	public Artista(String nome, Map<String, Album> albums) {
		super();
		this.albums = new HashMap<>();
		this.nome = nome;
		this.albums = albums;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Map<String, Album> getAlbums() {
		return albums;
	}

	public void setAlbums(Map<String, Album> albums) {
		this.albums = albums;
	}
}
