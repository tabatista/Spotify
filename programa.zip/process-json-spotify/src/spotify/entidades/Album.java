package spotify.entidades;

import java.util.ArrayList;
import java.util.List;

public class Album {

	private List<String> musicas;

	public Album() {
		super();
		this.musicas = new ArrayList<String>();
	}

	public List<String> getMusicas() {
		return musicas;
	}

	public void setMusicas(List<String> musicas) {
		this.musicas = musicas;
	}

}
